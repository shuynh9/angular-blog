import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { BlogPost } from '../blog-post';
import { PostService } from '../post.service';

@Component({
  selector: 'app-edit-post',
  templateUrl: './edit-post.component.html',
  styleUrls: ['./edit-post.component.css']
})
export class EditPostComponent implements OnInit {

  blogPost : BlogPost;
  tags : string;

  constructor(
    private _postService : PostService,
    private _activeRoute : ActivatedRoute,
    private route : Router    
  ) { }

  ngOnInit(): void {
    let id = this._activeRoute.snapshot.params['id'];
    this._postService.getPostById(id).subscribe(post => {
      this.blogPost = post;
      this.tags = this.blogPost.tags.toString();
    })
  }

  formSubmit(){
    this.blogPost.tags = this.tags.split(",").map(tag => tag.trim()); // convert string to an array and remove whitespace
    this._postService.updatePostById(this.blogPost._id, this.blogPost).subscribe(post => {
      this.route.navigate(['admin']);
    })
  }

  deletePostId(id: string){
    id = this.blogPost._id;
  
    this._postService.deletePostById(id).subscribe(post => {
      this.route.navigate(['admin']);
    })
  }

}
